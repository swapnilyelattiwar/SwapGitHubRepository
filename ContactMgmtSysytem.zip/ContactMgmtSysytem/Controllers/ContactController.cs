﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ContactDataAccess;

namespace ContactMgmtSystem.Controllers
{
    public class ContactController : ApiController
    {
        public HttpResponseMessage Get()
        {
            using (ContactDbEntities entity = new ContactDbEntities())
            {
                var contactList = entity.Contacts.ToList();

                if (contactList == null)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.NotFound, "No Contact details found in DB.");
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.OK, contactList);
                }
            }
        }

        public HttpResponseMessage Get(int id)
        {
            try
            {
                using (ContactDbEntities entity = new ContactDbEntities())
                {
                    var contact = entity.Contacts.FirstOrDefault(e => e.ID == id);

                    if (contact != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, contact);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Contact details with id " + id.ToString() + " not found.");
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }

        public HttpResponseMessage Post([FromBody]Contact contact)
        {
            try
            {
                using (ContactDbEntities entity = new ContactDbEntities())
                {
                    entity.Contacts.Add(contact);
                    entity.SaveChanges();

                    var message = Request.CreateResponse(HttpStatusCode.Created, contact);
                    message.Headers.Location = new Uri(Request.RequestUri + contact.ID.ToString());

                    return message;
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }

        public HttpResponseMessage Delete(int id)
        {
            try
            {
                using (ContactDbEntities entity = new ContactDbEntities())
                {
                    var contact = entity.Contacts.FirstOrDefault(e => e.ID == id);

                    if (contact == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Contact details with id " + id.ToString() + " is not found.");
                    }
                    else
                    {
                        entity.Contacts.Remove(contact);
                        entity.SaveChanges();
                        return Request.CreateResponse(HttpStatusCode.OK);
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }

        public HttpResponseMessage Put(int id, [FromBody]Contact contact)
        {
            try
            {
                using (ContactDbEntities entity = new ContactDbEntities())
                {
                    var contObj = entity.Contacts.FirstOrDefault(e => e.ID == id);

                    if (contObj == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Contact details with id " + id.ToString() + " is not found to update.");
                    }
                    else
                    {
                        contObj.FirstName = contact.FirstName;
                        contObj.LastName = contact.LastName;
                        contObj.Email = contact.Email;
                        contObj.PhoneNumber = contact.PhoneNumber;
                        contObj.Status = contact.Status;

                        entity.SaveChanges();

                        return Request.CreateResponse(HttpStatusCode.OK, contObj);
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }

    }
}
